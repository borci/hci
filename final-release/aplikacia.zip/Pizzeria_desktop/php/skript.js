$(document).ready(function(){
    //    ******************** triggery pre vysuvanie panelov *****************
                
    // inicializacia kosika
    init_kosik();
    
    // inicializacia adresy
    init_adresa();

    // inicializacia centralnej casti (menu pizze)    
    init_menu_pizze();
    
});
